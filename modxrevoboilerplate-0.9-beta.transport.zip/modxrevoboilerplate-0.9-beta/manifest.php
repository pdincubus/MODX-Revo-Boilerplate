<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'aabc02728997964773b0ec4a6bbfb49d',
      'native_key' => 'modxrevoboilerplate',
      'filename' => 'modNamespace/e95c1a14072f678f23d4bc8509a487c4.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '01a94cf2817a90f60f173ebab2f19938',
      'native_key' => 1,
      'filename' => 'modCategory/94024990a3c152a3dbbe9768bfc199ca.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
  ),
);