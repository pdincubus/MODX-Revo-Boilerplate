<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '6af10deacf89d196a347385013a7c1c2',
      'native_key' => 'modxrevoboilerplate',
      'filename' => 'modNamespace/9e550c46563bdad0ea42aa626f5faaa7.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '32ec6b48d74611596a847addc88d5c25',
      'native_key' => 1,
      'filename' => 'modCategory/34462a53e2659a8348a27093496b8a26.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'fe4b91be4abe81ab4ce47e5ce8648e0e',
      'native_key' => 'fe4b91be4abe81ab4ce47e5ce8648e0e',
      'filename' => 'xPDOTransportVehicle/6f6295ae34ef9fa616910b9c747dc770.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '3748cde1ec52242df66b92513da42334',
      'native_key' => '3748cde1ec52242df66b92513da42334',
      'filename' => 'xPDOTransportVehicle/a00f1e364378fd051bbc9bab94cff079.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '6d25e6be1248d9ef1deb070b0f9d3bbf',
      'native_key' => '6d25e6be1248d9ef1deb070b0f9d3bbf',
      'filename' => 'xPDOTransportVehicle/1332bb1f754e663df8428a0c312664a3.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'f8341e6e268d887dbf21658fc860dc2f',
      'native_key' => 'f8341e6e268d887dbf21658fc860dc2f',
      'filename' => 'xPDOTransportVehicle/f9c6bb71aec3b823aa7fb9e8ce7681f3.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '9dd926fb185946b4510334069c7c6e28',
      'native_key' => '9dd926fb185946b4510334069c7c6e28',
      'filename' => 'xPDOTransportVehicle/df63ae12ae83d530a580395912fb901a.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '7c86e2717577a87ee0748246e9938c24',
      'native_key' => '7c86e2717577a87ee0748246e9938c24',
      'filename' => 'xPDOTransportVehicle/5286d70f021ae1564aa3a2d80eb8253b.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '25a7af37700f99f104617f675c4318be',
      'native_key' => '25a7af37700f99f104617f675c4318be',
      'filename' => 'xPDOTransportVehicle/19983f5194925f7384291359a126a073.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '67ab19c91ca357512741ceb70949dad8',
      'native_key' => '67ab19c91ca357512741ceb70949dad8',
      'filename' => 'xPDOTransportVehicle/93d8d9cf8578efda3f8b29731f8de138.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'b01cb9881acce0329815b8a6a9da3338',
      'native_key' => 'b01cb9881acce0329815b8a6a9da3338',
      'filename' => 'xPDOTransportVehicle/0c0a49a9dd1a262a6462158330c0df0a.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '1159d4f83cc91866a42f7911409b59a4',
      'native_key' => '1159d4f83cc91866a42f7911409b59a4',
      'filename' => 'xPDOTransportVehicle/c4af160ffc2b4bcef7c1d63594e3b660.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '0e12628d3493317c9e688e706ca28f42',
      'native_key' => '0e12628d3493317c9e688e706ca28f42',
      'filename' => 'xPDOTransportVehicle/4f2a4d61602391c01460e3add38cc101.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
  ),
);