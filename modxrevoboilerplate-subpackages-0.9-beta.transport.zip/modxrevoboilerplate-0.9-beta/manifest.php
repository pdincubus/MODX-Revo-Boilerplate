<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'This work is licenced under the Creative Commons Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0)
http://creativecommons.org/licenses/by-sa/3.0/',
    'readme' => '#MODX Revolution Boilerplate basics

A bunch of stuff to quickly get some sensible basics into a new [MODX Revolution](http://modx.com/) install. There\'s a folder for each type of resource. Simply make a new resource of that particular type and copy in the code.

I\'ll probably try and set up a transport package for this at some point to make it even easier to use.


##Templates

###BaseTemplate

Used by default in MODX, very basic HTML structure. Pulls in a head and foot chunk.

###Article & ArticleContainer

For sites using Articles, you\'ll definitely want new templates for the layout in that section. These two templates have sane defaults and ensures all repeated code is pulled out into head, foot & articleSidebar chunks.


##Assets

Assets should usually be put in /assets/templates/{TEMPLATEFOLDERNAME}, e.g:

* CSS/LESS/Behaviour files: /assets/templates/{TEMPLATEFOLDERNAME}/css
* All javascript libraries, jQuery, Modernizr, etc: /assets/templates/{TEMPLATEFOLDERNAME}/js
* All images related to your template layout: /assets/templates/{TEMPLATEFOLDERNAME}/img
* etc.

The templates and chunks in this repository assume you\'ve put these files in the same place. If not, make sure you update the relevant paths.

###CSS

I use LESS just about all the time.

Includes the HTML5 Boilerplate normalise CSS (with a few tweaks), Internet Explorer HTC behaviour file for border-box box-sizing method, clearfixes, classes, and basic print styles. 

###js

Includes Modernizr for YepNope and making people think that old versions of Internet Explorer are futuristic. Kind of. Also includes local version jQuery for fallback should the CDN download fail, and jQuery Easing for nicer animations.


##Chunks

###head and foot

Beginning and end of the templates. I\'ve added two placeholders - [[+bodyClass]] and [[+template]].

[[+bodyClass]] is useful for complex sites and when passed into the [[$head]] will add that class name to the body tag. Can help save a bunch of extra templates (sometimes).

[[+template]] help make your [[$head]] & [[$foot]] more generic and easier to chuck into a new site without messing too much. See the BaseTemplate template for how to use.

###standardSidebar

Chuck everything in here that you would have in your aside. 

###articleSidebar

Contains most things that were pulled out of the stock Articles templates but are repeated on both container and article template. Nicely wrapped in an aside

###contactEmail and contactForm

Install the FormIt extra, and with these two simple chunks you can easily drop a working contact form on any page with little to no customisation required.

###wf.rowTpl

Wayfinder\'s default setup for outputting a menu item needs a bit of tweaking since we\'ve used the link_attributes to apply a class to the body tag.

###quipCommentCustom

Replacement, lovely and trimmed down version of the standard Quip chunk

###quipAddCommentCustom, ArticlesLatestPostTpl, ArchiveGroupByYear, ArticleRowTpl

See above.



##Snippets

###copyYears

Works out the copyright for the footer.

###currentUrl

Clue is in the name

###formatSearchUrl

Some preformatting for passing to the SimpleSearch on the Page Not Found error page.


##Content Pages

###Page Not Found

Requires SimpleSearch extra, formatSearchUrl and currentUrl snippets. Does a lookup for what page you tried to access and shows results in a list (if any).

###robots.txt

Disallows access to a bunch of MODX folders to SpiderBotMonkeys. Also points out the URL of the sitemap (edit this to your URL). You\'ll need to install the GoogleSiteMap extra to make the sitemap.xml file

###humans.txt

You can pretty much do what you want in this file, but point out developer, designer, technology used, etc.


##Extras

I generally use the following extras most of the time:

* Ace (code editor). <del>A lot better than CodeMirror</del>. The new version of CodeMirror is a lot better than the previous one. So either of these are decent. CodeMirror also has the option for colour schemes for syntax highlighting.
* Articles. This in turn installs a load of extras it needs
* Big Brother. A Google Analytics dashboard widget.
* FormIt. For form sending/validation, etc
* getRelated. Goes and sees if it can find content related to the page you\'re on. Useful in Articles pages.
* getResourceField. Useful for grabbing one bit of data from one single page. Kind of get resources, but blinkered.
* getResources. Useful for all kinds of things.
* GoogleSiteMap. Generates XML sitemaps for Spiders, etc
* [JSONDerulo](http://modx.com/extras/package/jsonderulo23). Pulls in and outputs JSON feeds for common social feeds.
* phpThumbOf. Crop, thumbnail and alter images automagically.
* SimpleSearch. For use on the Page Not Found error page.
* UltimateParent. Searches up branches to find parent pages at a chosen level. I use this for the bodyClass placeholder mostly.
* Wayfinder. Makes menus easy.


##Transport Package

This is *untested*. Be careful, the sky may fall down.

If you *only* want the snippets, chunks, assets and templates - use the default package. 

If you want the *full* package - install the "subpackages" transport package. This includes many of the above mentioned extras rolled in.

Assets are not included in this package. To install, FTP to your /core/packages/ directory, go to Package Management and instead of clicking "Download Extras", click the arrow and choose "Search Locally For Packages".

Then install in the usual way once the package is detected.

##Additional

Thanks (as usual) to [Mister John](https://github.com/johnnoel) for a couple of the snippets which accompany the SimpleSearch on the Page Not Found error page.',
    'changelog' => 'For all info: https://github.com/pdincubus/MODX-Revo-Boilerplate/

Most recent additions
---------------------

0.9b
	* Updated a bunch of everything. New test transport package',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '2296fa3b978d73c0e625d8e2b39cf788',
      'native_key' => 'modxrevoboilerplate',
      'filename' => 'modNamespace/a26e3d171e99ca8520ef2f4ea2f59ad3.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '6835991f2b0abbba88100b8791766c1b',
      'native_key' => 1,
      'filename' => 'modCategory/e2dc44a5890b4b973f9fa3913e219921.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '564be05e5fef738fc04a86bb9c39af7f',
      'native_key' => '564be05e5fef738fc04a86bb9c39af7f',
      'filename' => 'xPDOTransportVehicle/4aa6213a4d7e8ff508a67630d4984a2d.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '329094158fb8dea402beae754e252957',
      'native_key' => '329094158fb8dea402beae754e252957',
      'filename' => 'xPDOTransportVehicle/dd0e1902cf597a1a4095762cc97a7a5b.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'f91e3bdbcd05f0aabcbb3a844b590efc',
      'native_key' => 'f91e3bdbcd05f0aabcbb3a844b590efc',
      'filename' => 'xPDOTransportVehicle/817775250a0084cb9e96be5c86c6a394.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '64e36a3d655166993476a23c4822543b',
      'native_key' => '64e36a3d655166993476a23c4822543b',
      'filename' => 'xPDOTransportVehicle/d83025484f5a610c68e11836d9c30eae.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '4cc0aa7ba8bcdd7b989c53d125b77f27',
      'native_key' => '4cc0aa7ba8bcdd7b989c53d125b77f27',
      'filename' => 'xPDOTransportVehicle/c9780000c1923e6e3e10c1ccb101465e.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '0e9962521de9acec2ee30cb7f5f4a676',
      'native_key' => '0e9962521de9acec2ee30cb7f5f4a676',
      'filename' => 'xPDOTransportVehicle/bccdde5cfa0994893c606d2926d07a7e.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'd639ef36b060732d121ef745c84a1a88',
      'native_key' => 'd639ef36b060732d121ef745c84a1a88',
      'filename' => 'xPDOTransportVehicle/b0496c2759095d5482691d3d950a9784.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'b48aca34bf82136226f5209e38ac7180',
      'native_key' => 'b48aca34bf82136226f5209e38ac7180',
      'filename' => 'xPDOTransportVehicle/4506a6a9404a8a4b93efe3faf15a0ef1.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '79e7c74b705d8762fce8f008481db3d5',
      'native_key' => '79e7c74b705d8762fce8f008481db3d5',
      'filename' => 'xPDOTransportVehicle/715fe77114d9e4a15cfbf64332eb5264.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '295bb921ef5213b40094aad852a8b5d8',
      'native_key' => '295bb921ef5213b40094aad852a8b5d8',
      'filename' => 'xPDOTransportVehicle/6788990e183167ded0a73bd3c1d53171.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '4e967521ff2ead9d6983f90708f9c197',
      'native_key' => '4e967521ff2ead9d6983f90708f9c197',
      'filename' => 'xPDOTransportVehicle/d33d678b71b4d2617e8209e0ecb4708d.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
  ),
);