<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '#MODX Revolution Boilerplate basics

A bunch of stuff to quickly get some sensible basics into a new [MODX Revolution](http://modx.com/) install. There\'s a folder for each type of resource. Simply make a new resource of that particular type and copy in the code.

I\'ll probably try and set up a transport package for this at some point to make it even easier to use.


##Templates

###BaseTemplate

Used by default in MODX, very basic HTML structure. Pulls in a head and foot chunk.

###Article & ArticleContainer

For sites using Articles, you\'ll definitely want new templates for the layout in that section. These two templates have sane defaults and ensures all repeated code is pulled out into head, foot & articleSidebar chunks.


##Assets

Assets should usually be put in /assets/templates/{TEMPLATEFOLDERNAME}, e.g:

* CSS/LESS/Behaviour files: /assets/templates/{TEMPLATEFOLDERNAME}/css
* All javascript libraries, jQuery, Modernizr, etc: /assets/templates/{TEMPLATEFOLDERNAME}/js
* All images related to your template layout: /assets/templates/{TEMPLATEFOLDERNAME}/img
* etc.

The templates and chunks in this repository assume you\'ve put these files in the same place. If not, make sure you update the relevant paths.

###CSS

I use LESS just about all the time.

Includes the HTML5 Boilerplate normalise CSS (with a few tweaks), Internet Explorer HTC behaviour file for border-box bos-sizing method, clearfixes, classes, and basic print styles. 

###js

Includes Modernizr for YepNope and making people think that old versions of Internet Explorer are futuristic. Kind of. Also includes jQuery 1.7.2 for fallback should the CDN download fail, and jQuery Easing for nicer animations.


##Chunks

###head and foot

Beginning and end of the templates. I\'ve added two placeholders - [[+bodyClass]] and [[+template]].

[[+bodyClass]] is useful for complex sites and when passed into the [[$head]] will add that class name to the body tag. Can help save a bunch of extra templates (sometimes).

[[+template]] help make your [[$head]] & [[$foot]] more generic and easier to chuck into a new site without messing too much. See the BaseTemplate template for how to use.

###standardSidebar

Chuck everything in here that you would have in your aside. 

###articleSidebar

Contains most things that were pulled out of the stock Articles templates but are repeated on both container and article template. Nicely wrapped in an aside

###contactEmail and contactForm

Install the FormIt extra, and with these two simple chunks you can easily drop a working contact form on any page with little to no customisation required.

###wf.rowTpl

Wayfinder\'s default setup for outputting a menu item needs a bit of tweaking since we\'ve used the link_attributes to apply a class to the body tag.

###quipCommentCustom

Replacement, lovely and trimmed down version of the standard Quip chunk

###quipAddCommentCustom, ArticlesLatestPostTpl, ArchiveGroupByYear, ArticleRowTpl

See above.




##Snippets

###copyYears

Works out the copyright for the footer.

###currentUrl

Clue is in the name

###formatSearchUrl

Some preformatting for passing to the SimpleSearch on the Page Not Found error page.


##Content Pages

###Page Not Found

Requires SimpleSearch extra, formatSearchUrl and currentUrl snippets. Does a lookup for what page you tried to access and shows results in a list (if any).

###robots.txt

Disallows access to a bunch of MODX folders to SpiderBotMonkeys. Also points out the URL of the sitemap (edit this to your URL). You\'ll need to install the GoogleSiteMap extra to make the sitemap.xml file

###humans.txt

You can pretty much do what you want in this file, but point out developer, designer, technology used, etc.


##Extras

I generally use the following extras most of the time:

* Ace (code editor). A lot better than CodeMirror
* Articles. This in turn installs a load of extras it needs
* Big Brother. A Google Analytics dashboard widget.
* FormIt. For form sending/validation, etc
* getResourceField. Useful for grabbing one bit of data from one single page. Kind of get resources, but blinkered.
* getResources. Useful for all kinds of things.
* GoogleSiteMap. Generates XML sitemaps for Spiders, etc
* [JSONDerulo](http://modx.com/extras/package/jsonderulo23). Pulls in and outputs JSON feeds for common social feeds.
* phpThumbOf. Crop, thumbnail and alter images automagically.
* SimpleSearch. For use on the Page Not Found error page.
* UltimateParent. Searches up branches to find parent pages at a chosen level. I use this for the bodyClass placeholder mostly.
* Wayfinder. Makes menus easy.


##Additional

Thanks (as usual) to [Mister John](https://github.com/johnnoel) for a couple of the snippets which accompany the SimpleSearch on the Page Not Found error page.',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'af2ef224ff66a844dccb54f88f769fdb',
      'native_key' => 'modxrevoboilerplate',
      'filename' => 'modNamespace/eeffb6b8dd4ff4d48663f08b0b760f9c.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '838d34820076bb5eb614d364473e25db',
      'native_key' => 1,
      'filename' => 'modCategory/125ad98732870863c67d9a94bcf0ff8e.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '8ef12c794c1e7d19a5ecbb280c21cb23',
      'native_key' => '8ef12c794c1e7d19a5ecbb280c21cb23',
      'filename' => 'xPDOTransportVehicle/bc19e35992e35c5634154516eb0fc2ff.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '66aff36f21e2dbb10c28f6b58aadc20a',
      'native_key' => '66aff36f21e2dbb10c28f6b58aadc20a',
      'filename' => 'xPDOTransportVehicle/73b327f912419e84d8911104d74b5c38.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '05dc6d05fe53dc0762e7feb56002caec',
      'native_key' => '05dc6d05fe53dc0762e7feb56002caec',
      'filename' => 'xPDOTransportVehicle/30e2e4b757ee2810371a144f52f59c6e.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '3d58ee4aa2cedba95bead1a6ae91ba82',
      'native_key' => '3d58ee4aa2cedba95bead1a6ae91ba82',
      'filename' => 'xPDOTransportVehicle/ec3bc74153a5e9bb6d0a6ee5a695744f.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '40f3d5f316101bb520b3ad3082b37888',
      'native_key' => '40f3d5f316101bb520b3ad3082b37888',
      'filename' => 'xPDOTransportVehicle/86de3b69c60d9fe27d4e547fe2fb4472.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '6c661d0d468d2216a4a05676a609bae4',
      'native_key' => '6c661d0d468d2216a4a05676a609bae4',
      'filename' => 'xPDOTransportVehicle/da5d2059dd520ec68eccd21a46351d38.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '68182f58dd77c882f82237184910da98',
      'native_key' => '68182f58dd77c882f82237184910da98',
      'filename' => 'xPDOTransportVehicle/51d75dec54b3fd117a2132c96e667b88.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '3a1c77cbab7c2daa0d8406f6fd4d185e',
      'native_key' => '3a1c77cbab7c2daa0d8406f6fd4d185e',
      'filename' => 'xPDOTransportVehicle/81f23a0767aec722210a71aafc516d27.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '8e31560c80ba780671f359572f920818',
      'native_key' => '8e31560c80ba780671f359572f920818',
      'filename' => 'xPDOTransportVehicle/f16f3082a3dd5f44893a7c6e68711a72.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '5a514524e9c8c9d7c0d00b699c59b1a4',
      'native_key' => '5a514524e9c8c9d7c0d00b699c59b1a4',
      'filename' => 'xPDOTransportVehicle/60b14b0a75d7ca1a0c808b7600163ef5.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'df039d84ff9444420c380bff699ad616',
      'native_key' => 'df039d84ff9444420c380bff699ad616',
      'filename' => 'xPDOTransportVehicle/e0219611fc7e9f80f78e4bc01ef66140.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'c63fdb551d3496821a602e0bc9688d39',
      'native_key' => 'c63fdb551d3496821a602e0bc9688d39',
      'filename' => 'xPDOTransportVehicle/cfdf97f158a74e0d66e12a4f840347e2.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
  ),
);