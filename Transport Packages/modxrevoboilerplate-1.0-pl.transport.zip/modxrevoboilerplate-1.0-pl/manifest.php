<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '64df475a0b7b9b5a09b0270109b65dd8',
      'native_key' => 'modxrevoboilerplate',
      'filename' => 'modNamespace/e525248778deb5978dfa1bf39edf0959.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '367c1f38d81d521c2f8978b6676ed6c5',
      'native_key' => 1,
      'filename' => 'modCategory/69287b9bedff670b08f929243cc34e23.vehicle',
      'namespace' => 'modxrevoboilerplate',
    ),
  ),
);