<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ac7f1533f8ec4f9a49688edc5a4d209d',
      'native_key' => 'modxrevoboilerplatewithsubpackages',
      'filename' => 'modNamespace/fbcd36aea8d780a2603f0f5296b1b497.vehicle',
      'namespace' => 'modxrevoboilerplatewithsubpackages',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '9a3bbb7a8bdaee5aafe360b243be5677',
      'native_key' => 1,
      'filename' => 'modCategory/d5b218f3b3295598adba3b9163d4f325.vehicle',
      'namespace' => 'modxrevoboilerplatewithsubpackages',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '5f1029cc94af5652483b2d5cf9d2704c',
      'native_key' => '5f1029cc94af5652483b2d5cf9d2704c',
      'filename' => 'xPDOTransportVehicle/478bd11a5b5f10e985cd893129441032.vehicle',
      'namespace' => 'modxrevoboilerplatewithsubpackages',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'ec6193c1a5d4bb5d2d9df2c40c383bb4',
      'native_key' => 'ec6193c1a5d4bb5d2d9df2c40c383bb4',
      'filename' => 'xPDOTransportVehicle/d129261b297873242745d4272101ead0.vehicle',
      'namespace' => 'modxrevoboilerplatewithsubpackages',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '2d890967ab43a1ad999c63f40e159513',
      'native_key' => '2d890967ab43a1ad999c63f40e159513',
      'filename' => 'xPDOTransportVehicle/315de8f0869b99424514cbf1aed2368c.vehicle',
      'namespace' => 'modxrevoboilerplatewithsubpackages',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'aa0856867575e7c4bc2bbf0b0ab578da',
      'native_key' => 'aa0856867575e7c4bc2bbf0b0ab578da',
      'filename' => 'xPDOTransportVehicle/8f85c85511890c0fbddf81c0e5f69eec.vehicle',
      'namespace' => 'modxrevoboilerplatewithsubpackages',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'e92256628781aef188fdc2fbba0fad8f',
      'native_key' => 'e92256628781aef188fdc2fbba0fad8f',
      'filename' => 'xPDOTransportVehicle/e5e6a98d9548555b555f359a9808b815.vehicle',
      'namespace' => 'modxrevoboilerplatewithsubpackages',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '27cab39d0d82a2afd3a27ec00d49dac9',
      'native_key' => '27cab39d0d82a2afd3a27ec00d49dac9',
      'filename' => 'xPDOTransportVehicle/f041a1f2358886b04fd592eb9391aa0e.vehicle',
      'namespace' => 'modxrevoboilerplatewithsubpackages',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '1d5c3169e6c9a790ed75638c47d928c1',
      'native_key' => '1d5c3169e6c9a790ed75638c47d928c1',
      'filename' => 'xPDOTransportVehicle/b8dac18958db1f638a2fb6359122a5a2.vehicle',
      'namespace' => 'modxrevoboilerplatewithsubpackages',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '28bae2f348d1b158c73871975561bc82',
      'native_key' => '28bae2f348d1b158c73871975561bc82',
      'filename' => 'xPDOTransportVehicle/4e7da42d3bb5ca52e0ccfe031479bb4d.vehicle',
      'namespace' => 'modxrevoboilerplatewithsubpackages',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'f6ccc7b4edcaeea0d5caec54a924e23d',
      'native_key' => 'f6ccc7b4edcaeea0d5caec54a924e23d',
      'filename' => 'xPDOTransportVehicle/ba342583c2cf35d57b091db1e1e31c38.vehicle',
      'namespace' => 'modxrevoboilerplatewithsubpackages',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '097c0fec99c09ef8aca814140a58b5ce',
      'native_key' => '097c0fec99c09ef8aca814140a58b5ce',
      'filename' => 'xPDOTransportVehicle/c0aac9f87bccbe29025b2413ba487648.vehicle',
      'namespace' => 'modxrevoboilerplatewithsubpackages',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'e897f2db6c6a1af6a2b8d15d6757a2db',
      'native_key' => 'e897f2db6c6a1af6a2b8d15d6757a2db',
      'filename' => 'xPDOTransportVehicle/0b9ccefe1d4a923d0bcfd3f2b9561b01.vehicle',
      'namespace' => 'modxrevoboilerplatewithsubpackages',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '804d7cef4e77a99bec1172898cfb5d21',
      'native_key' => '804d7cef4e77a99bec1172898cfb5d21',
      'filename' => 'xPDOTransportVehicle/a12f8cf69da04f5ee8bef168e5130a63.vehicle',
      'namespace' => 'modxrevoboilerplatewithsubpackages',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => '9cbabc7212a67f107cf189978c835ded',
      'native_key' => '9cbabc7212a67f107cf189978c835ded',
      'filename' => 'xPDOTransportVehicle/25aa7e2fc65c0eceb904259296476567.vehicle',
      'namespace' => 'modxrevoboilerplatewithsubpackages',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOTransportVehicle',
      'class' => 'xPDOTransportVehicle',
      'guid' => 'f6d81e392232dc5b3ebc132cb4b7dcdf',
      'native_key' => 'f6d81e392232dc5b3ebc132cb4b7dcdf',
      'filename' => 'xPDOTransportVehicle/be15c7ee5b71f3326318df3b57c7088c.vehicle',
      'namespace' => 'modxrevoboilerplatewithsubpackages',
    ),
  ),
);